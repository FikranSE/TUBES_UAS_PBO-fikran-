import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

//class booking
public class bookingHotel extends Hotel
{
    //koneksi database
    Connection conn;
    String link = "jdbc:mysql://localhost:3306/hotel";
    
    Scanner input = new Scanner(System.in);
    String tglMasuk,tglKeluar, namaPembooking;
    Integer jmlhtiketMax = 15, kamar_tersedia, kamar_dipesan, total_harga;


    

    public void namaPemesan()
    {
        System.out.print("Nama Pemesan     : ");
        this.namaPembooking = input.nextLine();
    }
    public void tglMasuk()
    {
        System.out.print("Tanggal masuk    : ");
        this.tglMasuk = input.nextLine();
    }

    public void tglKeluar()
    {
        System.out.print("Tanggal keluar    : ");
        this.tglKeluar = input.nextLine();
    }

    public void harga()
    {
        System.out.print("Harga            : ");
        this.harga = input.nextInt();
    }

    public void jumlah_kamar()
    {
      
        System.out.print("Jumlah kamar     : ");
        kamar_dipesan = input.nextInt();
        {
            try 
            {
                if (kamar_dipesan <= 0 && kamar_dipesan > 15)  
                System.out.print("Tiket Tidak Tersedia");
            }

            catch (Exception nullpException)
            {
                System.out.println("\nERROR!\n");
            }
        }
    }

    public void total_harga()
    {
        // Total harga yang harus dibayar 
        this.total_harga = this.harga * this.kamar_dipesan;
        System.out.print("\nTotal Harga       :  Rp" + this.total_harga + "");
    }

    
    

    @Override
    public void save() throws SQLException 
    {
        try
        {
            view();
            System.out.println("\n----------Booking Hotel----------");
            namaPemesan();
            tglMasuk();
            tglKeluar();
            harga();
            jumlah_kamar();
            total_harga();


            conn = DriverManager.getConnection(link,"root","");
            Statement statement = conn.createStatement();
            String sql = "INSERT INTO bookinghotel (namaPembooking, tglMasuk, tglKeluar, harga, jumlahKamar) VALUES ('"+this.namaPembooking+"', '"+this.tglMasuk+"', '"+this.tglKeluar+"', '"+this.harga+"', '"+this.jumlahKamar+"')";
            statement.execute(sql);
            System.out.println("\nKamar Berhasil Dibooking");

        }

        //exception SQL
        catch(SQLException e)
        {
            System.err.println("\nKamar Gagal Dibooking");
        }

        //excception input tidak sesuai dengan tipe data
        catch(InputMismatchException e)
        {
            System.out.println("\nTipe Inputan Data Harus Benar");
        }
    }


    @Override
    public void delete() throws SQLException 
    {
        try
        {
            System.out.println("-------Pembatalan Booking-------");
            System.out.println("Nama pemesan : " );
            this.namaPembooking = input.next();

            String sql = "DELETE FROM bookinghotel WHERE nama = "+namaPembooking;
	        conn = DriverManager.getConnection(link, "root","");
	        Statement statement = conn.createStatement();
	        //ResultSet result = statement.executeQuery(sql);
	        
	        if(statement.executeUpdate(sql) > 0){
	            System.out.println("**Berhasil Menghapus Booking "+namaPembooking+"**");
	        }
        }

        catch(SQLException e){
	        System.out.println("Terjadi Kesalahan Penghapusan Data ");
	    }

        catch(Exception e){
            System.out.println("Masukan Nama Pemesan Yang Benar");
        }

    }

    
}



