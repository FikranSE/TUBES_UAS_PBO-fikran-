import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

//class Hotel
public class Hotel implements Database //class JadwalTravel yang mengimplementasikan interface Database
{
    //koneksi database
    Connection conn;
    String link = "jdbc:mysql://localhost:3306/hotel";
    Scanner input = new Scanner(System.in);

    String nama;
    String jumlahKamar; 
    String tglMasuk;
    String tglKeluar;
    Integer harga;

    public void method()
    {

    }

    //implementasi dari interface

    @Override
    public void insert() throws SQLException 
    {
        System.out.print("\n----------Tambah Jadwal Travel----------");
        System.out.print("\nNama Pemesan    : ");
        this.nama = input.nextLine();
        System.out.print("Jumlah kamar      : ");
        this.jumlahKamar = input.nextLine();
        System.out.print("Tanggal masuk     : ");
        this.tglMasuk = input.nextLine();
        System.out.print("Tanggal keluar    : ");
        this.tglKeluar = input.nextLine();
        System.out.print("Harga             : ");
        this.harga = input.nextInt();
    
        String sql = "INSERT INTO pesanKamar (nama, jumlahKamar, tglMasuk,  tglKeluar, harga) VALUES ('"+nama+"','"+jumlahKamar+"','"+tglMasuk+"','"+tglKeluar+"', '"+harga+"' )";
        conn = DriverManager.getConnection(link,"root","");
	    Statement statement = conn.createStatement();
	    statement.execute(sql);
	    System.out.println("Input Data Berhasil!");
        
        statement.close();
    }

    @Override
    public void view() throws SQLException 
    {
        //mengakses data yang berada di database jadwal_travel
        String sql = "SELECT * FROM pesanKamar";
        conn = DriverManager.getConnection(link,"root","");
        Statement statement = conn.createStatement();
		ResultSet result = statement.executeQuery(sql);

        while (result.next())
        {
        System.out.print("\nNama Pemesan    : ");
        System.out.println(result.getString("nama"));
        System.out.print("Jumlah kamar      : ");
        System.out.println(result.getString("jumlahKamar"));
        System.out.print("Tanggal masuk     : ");
        System.out.println(result.getString("tglMasuk"));
        System.out.print("Tanggal keluar    : ");
        System.out.println(result.getString("tglKeluar"));
        System.out.print("Harga             : ");
        System.out.println(result.getInt("harga"));
        }
        
        statement.close();
    }
    
    @Override
    public void update() throws SQLException 
    {
        //try
        try
        {
            view();
            Integer pil;
            System.out.print("\n----------Ubah Pemesanan----------");
            System.out.print("\nNama Pemesan : ");
            String ubah = input.nextLine();

            //mengakses data database jaya_travel tabel jadwal_travel
            String sql = "SELECT * FROM pesanKamar WHERE nama ='"+ubah+"'";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);

            //percabangan  if
            if (result.next())
            {
                System.out.println("\nData yang akan diubah \n1.Jumlah Kamar\n2.Tanggal masuk\n3.Tangggal keluar\n4.Harga");
                System.out.print("Pilihan Anda [1/2] : ");
                pil = input.nextInt();
                input.nextLine();
        
                //percabangan switch case
                switch (pil)
                {
                    case 1:
                        System.out.print("\nJumlah Kamar ["+result.getString("jumlahkamar")+"]\t: ");
                        String ubah1 = input.nextLine();
                        //update data  database hotel tabel pesanKamar
                        sql = "UPDATE pesanKamar SET jumlahKamar = '"+ubah1+"' WHERE nama ='"+ubah+"'";
                        if(statement.executeUpdate(sql) > 0)
                        {
                            System.out.println("Berhasil Mengubah jumlah kamar!");
                        }
                    break;
        
                    case 2:
                        System.out.print("\nTanggal masuk ["+result.getInt("tglMasuk")+"]\t: ");
                        Integer ubah2 = input.nextInt();
                        //update data  database jaya_travel tabel pesanKamar
                        sql = "UPDATE pesanKamar SET tglMasuk = "+ubah2+" WHERE nama ='"+ubah+"'";
                        input.nextLine();
                        if(statement.executeUpdate(sql) > 0)
                        {
                            System.out.println("Berhasil Mengubah tanggal masuk!");
                        }
                    break;
                    case 3:
                        System.out.print("\nTanggal keluar ["+result.getInt("tglKeluar")+"]\t: ");
                        Integer ubah3 = input.nextInt();
                        sql = "UPDATE pesanKamar SET tglkeluar = "+ubah3+" WHERE nama ='"+ubah+"'";
                        input.nextLine();
                        if(statement.executeUpdate(sql) > 0)
                        {
                            System.out.println("Berhasil Mengubah tanggal keluar!");
                        }
                    break;
                    case 4:
                        System.out.print("\nHarga ["+result.getInt("harga")+"]\t: ");
                        Integer ubah4 = input.nextInt();
                        sql = "UPDATE pesanKamar SET harga = "+ubah4+" WHERE nama ='"+ubah+"'";
                        input.nextLine();
                        if(statement.executeUpdate(sql) > 0)
                        {
                            System.out.println("Berhasil Mengubah harga!");
                        }
                    break;

                    default :
                        System.out.println("\n\t***ERROR***");
                        System.out.println("Input Angka 1 atau 2 Saja!");
                    break;
                }
            }

            else
            {
                System.out.println("**Error!**");
            }
        }

        //exeption SQL 
        catch (SQLException e)
        {
            System.err.println("Update Data Gagal");
        }

        //exception input tidak sesuai jenis data
        catch (InputMismatchException e)
        {
            System.err.println("Gagal! Masukkan Data yang Benar");
        }
    }



    public void save() throws SQLException 
    {
        
    }

    public void delete() throws SQLException 
    {
        
    }
}
